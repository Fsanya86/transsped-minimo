jQuery(document).ready(function ($) {
	
	//Initialize selectWoo on admin settings screen
	$("#transsped_shipping_ids").selectWoo();
	
});
