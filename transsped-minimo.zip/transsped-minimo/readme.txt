=== Transsped ===
Contributors: fsanya
Tags: transsped
Requires at least: 6.0
Tested up to: 6.6.1
Requires PHP: 7.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Transsped integráció Woocommerce alapú webshophoz

== Description ==
Ezzel a bővítménnyel néhány kattintással létrehozhatsz csomagokat a Transsped rendszerében. A csomagokhoz azonnal nyomtatható címke is készül, ami a saját szerveren is tárolva lesz, így bármikor újra használható.

Beállítások: WooCommerce / Beállítások / Transsped fül

== Installation ==
1. Töltsd le a bővítményt
2. WordPress-ben bővítmények / új hozzáadása menüben fel kell tölteni
VAGY
1. Bővítmények / új hozzáadása menüben keress rá a \"transsped\" szóra
2. Kattints a \"telepítés\" majd az \"aktiválás\" gombra.
---
3. WooCommerce / Beállítások / Transsped fülön találod a beállításokat


== Changelog ==
1.0 Initial release